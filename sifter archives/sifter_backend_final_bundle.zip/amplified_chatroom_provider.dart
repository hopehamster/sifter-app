import 'package:flutter/material.dart';
import '../models/chat_room.dart';
import '../services/amplify_chatroom_service.dart';

class ChatRoomProvider with ChangeNotifier {
  final AmplifyChatRoomService _chatRoomService = AmplifyChatRoomService();
  List<ChatRoom> _chatRooms = [];

  List<ChatRoom> get chatRooms => _chatRooms;

  Future<void> loadRooms() async {
    try {
      final data = await _chatRoomService.listRooms();
      _chatRooms = data.map((item) => ChatRoom(
        id: item['id'],
        name: item['name'],
        participantIds: List<String>.from(item['participantIds'] ?? []),
        latitude: item['latitude']?.toDouble() ?? 0,
        longitude: item['longitude']?.toDouble() ?? 0,
        radiusInMeters: item['radiusInMeters']?.toDouble() ?? 100,
      )).toList();
      notifyListeners();
    } catch (e) {
      debugPrint("Error loading rooms: \$e");
    }
  }

  Future<void> addRoom(ChatRoom room) async {
    try {
      await _chatRoomService.createRoom(
        name: room.name,
        participantIds: room.participantIds,
        latitude: room.latitude,
        longitude: room.longitude,
        radiusInMeters: room.radiusInMeters,
      );
      _chatRooms.add(room);
      notifyListeners();
    } catch (e) {
      debugPrint("Add room error: \$e");
    }
  }
}