import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:uuid/uuid.dart';

class AmplifyChatService {
  final _uuid = Uuid();

  // Send a message
  Future<void> sendMessage({
    required String roomId,
    required String senderId,
    required String text,
  }) async {
    final timestamp = TemporalDateTime.now();
    final messageId = _uuid.v4();

    final mutation = '''mutation CreateMessage {
      createMessage(input: {
        id: "$messageId",
        roomId: "$roomId",
        senderId: "$senderId",
        text: "$text",
        timestamp: "$timestamp",
        isRead: false
      }) {
        id
        text
      }
    }''';

    try {
      final request = GraphQLRequest<String>(
        document: mutation,
      );
      final response = await Amplify.API.mutate(request: request).response;

      if (response.errors.isNotEmpty) {
        throw Exception(response.errors.first.message);
      }
    } catch (e) {
      safePrint('SendMessage failed: \$e');
    }
  }

  // Subscribe to real-time messages
  Stream<GraphQLResponse<String>> subscribeToMessages(String roomId) {
    final subscription = '''subscription OnCreateMessage {
      onCreateMessage {
        id
        roomId
        text
        senderId
        timestamp
      }
    }''';

    final request = GraphQLRequest<String>(document: subscription);
    return Amplify.API.subscribe(request, onEstablished: () {
      safePrint("Subscription connected");
    });
  }

  // List messages by room
  Future<List<Map<String, dynamic>>> listMessages(String roomId) async {
    final query = '''query ListMessages {
      listMessages(filter: { roomId: { eq: "$roomId" } }) {
        items {
          id
          text
          senderId
          timestamp
        }
      }
    }''';

    final request = GraphQLRequest<String>(document: query);
    final response = await Amplify.API.query(request: request).response;

    if (response.errors.isNotEmpty) {
      throw Exception(response.errors.first.message);
    }

    final data = response.data;
    final decoded = data != null ? jsonDecode(data) : {};
    return List<Map<String, dynamic>>.from(decoded['listMessages']['items'] ?? []);
  }
}