import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:uuid/uuid.dart';

class AmplifyChatRoomService {
  final _uuid = Uuid();

  Future<void> createRoom({
    required String name,
    required List<String> participantIds,
    double? latitude,
    double? longitude,
    double? radiusInMeters,
  }) async {
    final roomId = _uuid.v4();

    final mutation = '''mutation CreateChatRoom {
      createChatRoom(input: {
        id: "$roomId",
        name: "$name",
        participantIds: ${jsonEncode(participantIds)},
        latitude: $latitude,
        longitude: $longitude,
        radiusInMeters: $radiusInMeters
      }) {
        id
        name
      }
    }''';

    final request = GraphQLRequest<String>(document: mutation);
    final response = await Amplify.API.mutate(request: request).response;

    if (response.errors.isNotEmpty) {
      throw Exception(response.errors.first.message);
    }
  }

  Future<List<Map<String, dynamic>>> listRooms() async {
    final query = '''query ListChatRooms {
      listChatRooms {
        items {
          id
          name
          participantIds
          latitude
          longitude
          radiusInMeters
        }
      }
    }''';

    final request = GraphQLRequest<String>(document: query);
    final response = await Amplify.API.query(request: request).response;

    if (response.errors.isNotEmpty) {
      throw Exception(response.errors.first.message);
    }

    final data = jsonDecode(response.data!);
    return List<Map<String, dynamic>>.from(data['listChatRooms']['items']);
  }
}