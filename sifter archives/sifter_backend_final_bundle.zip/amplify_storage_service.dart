import 'dart:io';
import 'package:amplify_flutter/amplify_flutter.dart';

class AmplifyStorageService {
  // Upload image to S3
  Future<String> uploadAvatar(File file, String userId) async {
    final key = 'avatars/\$userId-\${DateTime.now().millisecondsSinceEpoch}.jpg';

    try {
      final UploadFileResult result = await Amplify.Storage.uploadFile(
        local: file,
        key: key,
        options: const StorageUploadFileOptions(
          accessLevel: StorageAccessLevel.protected,
        ),
      );
      return key;
    } catch (e) {
      safePrint("Upload error: \$e");
      rethrow;
    }
  }

  // Get signed URL
  Future<String> getAvatarUrl(String key) async {
    try {
      final result = await Amplify.Storage.getUrl(
        key: key,
        options: const StorageGetUrlOptions(
          accessLevel: StorageAccessLevel.protected,
        ),
      );
      return result.url;
    } catch (e) {
      safePrint("Get URL error: \$e");
      rethrow;
    }
  }
}