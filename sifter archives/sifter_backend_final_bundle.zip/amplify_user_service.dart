import 'package:amplify_flutter/amplify_flutter.dart';

class AmplifyUserService {
  // Update Cognito user attributes
  Future<void> updateDisplayName(String name) async {
    try {
      await Amplify.Auth.updateUserAttribute(
        userAttributeKey: CognitoUserAttributeKey.name,
        value: name,
      );
    } catch (e) {
      safePrint("Update display name failed: \$e");
      rethrow;
    }
  }

  // Save avatar URL to GraphQL User model
  Future<void> updateAvatarInGraphQL({
    required String userId,
    required String avatarUrl,
  }) async {
    final mutation = '''
    mutation UpdateUser {
      updateUser(input: {
        id: "\$userId",
        avatarUrl: "\$avatarUrl"
      }) {
        id
        avatarUrl
      }
    }
    ''';

    try {
      final request = GraphQLRequest<String>(document: mutation);
      final response = await Amplify.API.mutate(request: request).response;

      if (response.errors.isNotEmpty) {
        throw Exception(response.errors.first.message);
      }
    } catch (e) {
      safePrint("Update avatar in GraphQL failed: \$e");
      rethrow;
    }
  }
}