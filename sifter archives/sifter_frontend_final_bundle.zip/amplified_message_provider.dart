import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/message.dart';
import '../models/user.dart';
import '../services/amplify_chat_service.dart';

class MessageProvider with ChangeNotifier {
  final User _currentUser;
  final Map<String, List<Message>> _messages = {};
  final AmplifyChatService _chatService = AmplifyChatService();

  MessageProvider({required User currentUser}) : _currentUser = currentUser;

  User get currentUser => _currentUser;

  List<Message> getMessages(String roomId) => _messages[roomId] ?? [];

  // Load messages from backend
  Future<void> loadMessages(String roomId) async {
    try {
      final raw = await _chatService.listMessages(roomId);
      final messages = raw.map((item) {
        return Message(
          id: item['id'],
          text: item['text'],
          senderId: item['senderId'],
          timestamp: DateTime.parse(item['timestamp']),
          isRead: item['isRead'] ?? false,
        );
      }).toList();
      _messages[roomId] = messages;
      notifyListeners();
    } catch (e) {
      debugPrint("Error loading messages: \$e");
    }
  }

  // Send a message via Amplify
  Future<void> addMessage(String roomId, String text) async {
    try {
      await _chatService.sendMessage(
        roomId: roomId,
        senderId: _currentUser.id,
        text: text,
      );
    } catch (e) {
      debugPrint("Send message error: \$e");
    }
  }

  // Subscribe to new messages
  void subscribeToMessages(String roomId) {
    final stream = _chatService.subscribeToMessages(roomId);
    stream.listen((event) {
      final data = jsonDecode(event.data);
      final message = Message(
        id: data['onCreateMessage']['id'],
        text: data['onCreateMessage']['text'],
        senderId: data['onCreateMessage']['senderId'],
        timestamp: DateTime.parse(data['onCreateMessage']['timestamp']),
        isRead: false,
      );
      _messages.putIfAbsent(roomId, () => []).add(message);
      notifyListeners();
    }, onError: (error) {
      debugPrint("Subscription error: \$error");
    });
  }

  void markMessageAsRead(String roomId, String messageId) {
    final roomMsgs = _messages[roomId];
    if (roomMsgs != null) {
      final index = roomMsgs.indexWhere((msg) => msg.id == messageId);
      if (index != -1) {
        final msg = roomMsgs[index];
        roomMsgs[index] = msg.copyWith(isRead: true);
        notifyListeners();
      }
    }
  }
}