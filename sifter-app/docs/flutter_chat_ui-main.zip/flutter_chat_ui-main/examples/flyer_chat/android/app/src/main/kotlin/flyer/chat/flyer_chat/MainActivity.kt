package flyer.chat.flyer_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
