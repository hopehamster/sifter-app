/// Flyer Chat Text Message package. Provides a widget for simple text messages.
library;

export 'src/flyer_chat_text_message.dart';
