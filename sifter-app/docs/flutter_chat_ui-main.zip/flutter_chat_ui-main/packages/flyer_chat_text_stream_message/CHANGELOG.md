## 2.1.6

 - Update a dependency to the latest release.

## 2.1.5

 - Update a dependency to the latest release.

## 2.1.4

 - Update a dependency to the latest release.

## 2.1.3

 - Update a dependency to the latest release.

## 2.1.2

 - Update a dependency to the latest release.

## 2.1.1

 - Update a dependency to the latest release.

## 2.1.0

 - **FEAT**: rename chat controller methods. ([dc1bf57d](https://github.com/flyerhq/flutter_chat_ui/commit/dc1bf57d9b5f9655805589fdda5581759b9cc1a9))

## 2.0.4

 - Update a dependency to the latest release.

## 2.0.3

 - **FIX**: add example. ([77c55e82](https://github.com/flyerhq/flutter_chat_ui/commit/77c55e829ebac99a0e7c754258b7e4f39767ca9e))

## 2.0.2

 - **FIX**: improve documentation. ([19ce9641](https://github.com/flyerhq/flutter_chat_ui/commit/19ce9641d341cd297cd83219e989914e7bc78af0))

## 2.0.1

 - **FIX**: document public APIs.

## 2.0.0

- First stable release

## 0.0.12

- Initial release
