/// Flyer Chat Text Stream Message package. Provides a widget for streamed text messages.
library;

export 'src/flyer_chat_text_stream_message.dart';
export 'src/stream_state.dart';
export 'src/text_segment.dart';
