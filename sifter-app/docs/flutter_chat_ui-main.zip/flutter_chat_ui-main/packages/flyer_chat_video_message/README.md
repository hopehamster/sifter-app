# [Flyer Chat](https://flyer.chat) 💬 Video Message Widget (Planned)

[![Pub Version](https://img.shields.io/pub/v/flyer_chat_video_message?logo=flutter&color=orange)](https://pub.dev/packages/flyer_chat_video_message) [![Stars](https://img.shields.io/github/stars/flyerhq/flutter_chat_ui?style=flat&color=orange&logo=github)](https://github.com/flyerhq/flutter_chat_ui/stargazers) [![melos](https://img.shields.io/badge/maintained%20with-melos-ffffff.svg?color=orange)](https://github.com/invertase/melos)

**Note:** This package is planned but not yet implemented 🚧.

This package will provide an opinionated video message widget for use with the [`flutter_chat_ui`](https://github.com/flyerhq/flutter_chat_ui/tree/main/packages/flutter_chat_ui) package.
