library flutter_link_previewer;

export 'src/types.dart';
export 'src/utils.dart' show getPreviewData, regexEmail, regexLink;
export 'src/widgets/link_preview.dart';
