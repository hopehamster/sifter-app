import React from 'react';
import ReactDOM from 'react-dom';
import { Amplify } from 'aws-amplify';
import awsconfig from './aws-exports';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Users from './pages/Users';
import Rooms from './pages/Rooms';
import Analytics from './pages/Analytics';

Amplify.configure(awsconfig);

ReactDOM.render(
  <BrowserRouter>
    <Routes>
      <Route path="/users" element={<Users />} />
      <Route path="/rooms" element={<Rooms />} />
      <Route path="/analytics" element={<Analytics />} />
    </Routes>
  </BrowserRouter>,
  document.getElementById('root')
);