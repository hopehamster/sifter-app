import React, { useState, useEffect } from 'react';
import { API, Auth } from 'aws-amplify';

function Users() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    const response = await API.graphql({
      query: `
        query ListUsers {
          listUsers { items { id email } }
        }
      `,
    });
    setUsers(response.data.listUsers.items);
  }

  async function deleteUser(userId) {
    await API.graphql({
      query: `
        mutation DeleteAccount($userId: String!) {
          deleteAccount(userId: $userId)
        }
      `,
      variables: { userId },
    });
    fetchUsers();
  }

  return (
    <div>
      <h1>User Management</h1>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {user.email}
            <button onClick={() => deleteUser(user.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Users;