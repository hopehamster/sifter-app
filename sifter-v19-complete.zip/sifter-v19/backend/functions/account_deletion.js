const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient();
exports.handler = async (event) => {
  const userId = event.arguments.userId;
  await docClient.delete({ TableName: 'Message', Key: { userId } }).promise();
  await docClient.delete({ TableName: 'ChatRoom', Key: { creatorId: userId } }).promise();
  return true;
};