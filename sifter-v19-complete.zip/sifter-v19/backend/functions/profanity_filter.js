const BadWords = require('bad-words');
const filter = new BadWords();
exports.handler = async (event) => {
  const text = event.arguments.content;
  return filter.clean(text);
};