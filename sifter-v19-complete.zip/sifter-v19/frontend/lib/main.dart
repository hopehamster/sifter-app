import 'package:flutter/material.dart';
import 'package:amplify_flutter/amplify_flutter.dart';
import 'package:amplify_auth_cognito/amplify_auth_cognito.dart';
import 'package:amplify_api/amplify_api.dart';
import 'amplifyconfiguration.dart';
import 'screens/home_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/chat_room_create_screen.dart';
import 'screens/join_room_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Amplify.configure(amplifyconfig);
  Amplify.addPlugins([AmplifyAuthCognito(), AmplifyAPI()]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/home',
      routes: {
        '/home': (context) => HomeScreen(),
        '/chat': (context) => ChatScreen(),
        '/profile': (context) => ProfileScreen(),
        '/settings': (context) => SettingsScreen(),
        '/create-room': (context) => ChatRoomCreateScreen(),
        '/join-room': (context) => JoinRoomScreen(),
      },
      theme: ThemeData(primarySwatch: Colors.blue),
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.chat), label: "Chat"),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: "Settings"),
        ],
        currentIndex: 0,
        onTap: (index) {
          switch (index) {
            case 0: Navigator.pushNamed(context, '/home'); break;
            case 1: Navigator.pushNamed(context, '/chat'); break;
            case 2: Navigator.pushNamed(context, '/profile'); break;
            case 3: Navigator.pushNamed(context, '/settings'); break;
          }
        },
      ),
    );
  }
}